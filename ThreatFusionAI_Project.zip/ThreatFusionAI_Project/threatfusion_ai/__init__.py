"""
ThreatFusion AI — Defensive Threat Intelligence Fusion System
================================================================
Built for AICS-107: AI-Powered Threat Intelligence (ICDFA).

This package is strictly defensive. It operates only on synthetic,
safely-generated threat intelligence data (or optional metadata-only
enrichment from public feeds). It does not visit, download, or execute
any live malicious content.
"""

__version__ = "0.1.0"
