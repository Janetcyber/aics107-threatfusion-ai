# ThreatFusion AI

A defensive threat intelligence fusion pipeline built for AICS-107 (AI-Powered Threat Intelligence, ICDFA).

## What this does
Turns raw CTI reports into usable intelligence: IOC extraction, ATT&CK technique mapping (ML-based),
campaign clustering via a knowledge graph, risk scoring, STIX 2.1-style export, and analyst report generation.

All data is 100% synthetic (RFC 5737 documentation IP ranges, .example/.test/.invalid domains). No real
malicious URLs, malware, or credentials are used or generated anywhere in this project.

## Setup
```bash
cd ThreatFusionAI_Project
chmod +x setup_linux.sh
./setup_linux.sh
source venv/bin/activate
```

## Usage
```bash
# Generate synthetic CTI report corpus
python -m threatfusion_ai.cli init-data

# Train the ATT&CK mapping classifier
python -m threatfusion_ai.cli train

# Run the full pipeline (IOC extraction, mapping, graph, clustering, risk scoring, STIX export)
python -m threatfusion_ai.cli run-pipeline

# Generate an analyst report for a specific case
python -m threatfusion_ai.cli report --case-id RPT-0001
```

## Project structure
```
ThreatFusionAI_Project/
├── setup_linux.sh
├── requirements.txt
├── threatfusion_ai/          # main package (CLI + pipeline modules)
├── data/
│   ├── raw/                  # generated synthetic CTI reports
│   └── processed/            # enriched cases with IOCs, ATT&CK labels, risk scores
└── outputs/
    ├── model_evaluation.txt
    ├── stix/                 # STIX 2.1-style bundle
    ├── graphs/                # threat knowledge graph
    └── reports/               # analyst reports (Markdown)
```

## Safety
All exercises are for defensive threat intelligence, SOC enrichment, incident response, and research
training. No live malicious URLs are visited, no malware samples are downloaded, and this intelligence
is not used to attack third-party systems.
