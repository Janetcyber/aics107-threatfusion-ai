#!/bin/bash
# ThreatFusion AI — Linux environment setup script
# Creates a Python virtual environment and installs all dependencies.

set -e

echo "=================================================="
echo "ThreatFusion AI — Environment Setup"
echo "=================================================="

if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

echo "Activating virtual environment..."
source venv/bin/activate

echo "Upgrading pip..."
pip install --upgrade pip --quiet

echo "Installing dependencies from requirements.txt..."
pip install -r requirements.txt --quiet

echo "Creating project folder structure..."
mkdir -p data/raw data/processed outputs/stix outputs/graphs outputs/reports

echo ""
echo "Setup complete. Virtual environment is active for this shell session."
echo "For future sessions, activate it manually with:"
echo "    source venv/bin/activate"
echo ""
echo "Next step: python -m threatfusion_ai.cli init-data"
